# webapp
webapp Prerequisites: The following are to be installed:

Node.js MySQL Server npm A code editor - Visual Studio Code Application to view/access mysql database - command line REST API testing tool - Postman

Installation Steps:

Clone repository from GitHub. Open the code in the code editor of your choice, and run the command npm install. This will install all the dependencies listed in package.json. Run the command npm start. While running locally, the application will be hosted at http://localhost:8080.

There are four API endpoints: create new users:localhost:8080/api/user update users' information:localhost:8080/api/user/update find users' information:localhost:8080/api/user/find find by id:localhost:8080/api/user/findid

That's all
